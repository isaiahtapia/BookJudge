DROP DATABASE IF EXISTS traveller_db;
CREATE DATABASE traveller_db;

-- change the db name to name of app